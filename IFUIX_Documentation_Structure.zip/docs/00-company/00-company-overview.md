# Company Overview

## Purpose
IFUIX is a software company focused on thoughtful, privacy-first desktop applications.

## Core Values
- Privacy First
- Offline First
- Quality over Quantity
- Beautiful UX
- Reliability