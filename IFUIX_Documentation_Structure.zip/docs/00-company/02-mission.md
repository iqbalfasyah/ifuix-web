# Mission

Create beautifully crafted software that improves everyday productivity without sacrificing privacy.