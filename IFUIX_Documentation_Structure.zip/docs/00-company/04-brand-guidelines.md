# Brand Guidelines

Company: IFUIX
Product: Fuira
Tone: Friendly, Professional, Minimal.