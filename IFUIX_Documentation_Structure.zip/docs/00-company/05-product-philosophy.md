# Product Philosophy

Products should solve real problems, remain simple, and work offline whenever possible.