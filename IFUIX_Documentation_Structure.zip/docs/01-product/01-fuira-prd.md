# Fuira PRD

Purpose, users, features, architecture, roadmap and release goals.