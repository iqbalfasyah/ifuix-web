# Roadmap

v1.0 MVP
v1.1 Productivity
v1.2 AI
v2 Cross Platform