# Feedback Process

Collect issues, prioritize, iterate weekly.