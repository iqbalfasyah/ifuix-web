# Color System

Primary: #F59E0B
Secondary: #FB923C
Background: #FAFAFA