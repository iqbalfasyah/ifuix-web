# Typography

Geist
Inter
Responsive scale.