# Spacing

Use an 8px spacing system.