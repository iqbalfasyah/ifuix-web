# Animation

Subtle, meaningful, 200–300ms.