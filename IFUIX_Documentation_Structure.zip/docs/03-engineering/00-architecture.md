# Architecture

React + Vite + TypeScript + Tailwind.