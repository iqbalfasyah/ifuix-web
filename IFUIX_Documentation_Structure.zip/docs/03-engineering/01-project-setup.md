# Project Setup

Create Vite project and configure tooling.