# Folder Structure

Organize by components, sections, pages.