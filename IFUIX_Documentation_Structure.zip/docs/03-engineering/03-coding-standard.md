# Coding Standard

ESLint, Prettier, strict TypeScript.