# Performance

Lazy loading, image optimization, Lighthouse 95+.