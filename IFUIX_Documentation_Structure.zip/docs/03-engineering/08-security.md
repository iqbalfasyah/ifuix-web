# Security

HTTPS, CSP, dependency updates.