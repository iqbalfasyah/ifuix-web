# Deployment

GitHub Actions → GitHub Pages.