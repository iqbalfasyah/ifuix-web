# GitHub Actions

Build and deploy on push to main.