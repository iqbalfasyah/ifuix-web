# Bug Report Template

Steps, expected, actual, screenshots.